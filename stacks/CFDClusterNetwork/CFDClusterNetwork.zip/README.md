# oci-hpc-clusternetwork
Cluster Network Stack for CFD image

This version adds
- Gluster
- CFD librairies
- OpenFOAM installation and benchamrk
- Locale script

